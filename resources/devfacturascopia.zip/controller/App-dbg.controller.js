sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("dev.facturas.copia.controller.App", {
      onInit() {
      }
  });
});